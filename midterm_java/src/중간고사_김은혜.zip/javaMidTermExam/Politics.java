package javaMidTermExam;

public class Politics {
	String name;
	String address;
	int age;
	String userInputPolitic;
	
	
	Politics(String name, String address, int age, String userInputPolitic) {
		this.name = name;
		this.address = address;
		this.age = age;
		this.userInputPolitic = userInputPolitic;
	}
}
